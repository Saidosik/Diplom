<?php

namespace App\Models;

use App\Enums\PublicationStatus;
use App\Enums\PublicationType;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

#[Fillable('author_id',
        'type',
        'title',
        'slug',
        'excerpt',
        'status',
        'cover_image_path',
        'reading_time_minutes',
        'published_at',)]

class Publication extends Model
{
    use SoftDeletes;

    protected function casts(): array
    {
        return [
            'type' => PublicationType::class,
            'status' => PublicationStatus::class,
            'published_at' => 'datetime',
            'reading_time_minutes' => 'integer',
        ];
    }

    public function author(): BelongsTo
    {
        return $this->belongsTo(User::class, 'author_id');
    }

    public function blocks(): HasMany
    {
        return $this->hasMany(PublicationBlock::class)
            ->orderBy('sort_order');
    }

    public function scopePublished(Builder $query): Builder
    {
        return $query->where('status', PublicationStatus::Published);
    }

    public function isPublished(): bool
    {
        return $this->status === PublicationStatus::Published;
    }

    public function isAuthor(?User $user): bool
    {
        return $user !== null && $this->author_id === $user->id;
    }
}
