<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('lesson_blocks', function (Blueprint $table) {
            $table->id();
            $table->string('name',255);
            $table->unsignedBigInteger('order');
            $table->foreignId('lesson_id')->references('id')->on('lessons')->constrained()->onDelete('cascade');
            $table->enum('status',['off', 'visible']);
            $table->enum('type',['theory', 'test', 'coding_task']);
            //$table->string('prewiew');
            //$table->string('icon');
            $table->softDeletes();
            $table->timestamps();

            // Индексы
            $table->index(['lesson_id', 'status']);  // Для фильтрации блоков урока
            $table->index(['type', 'status']);  // Для фильтрации по типу
            $table->index('order');  // Для сортировки
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('lesson_blocks');
    }
};
