<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('lessons', function (Blueprint $table) {
            $table->id();
            $table->string('name',255);
            $table->unsignedBigInteger('order');
            $table->string('description')->nullable();
            $table->foreignId('module_id')->references('id')->on('modules')->constrained()->onDelete('cascade');
            $table->enum('status',['off', 'visible']);
            //$table->string('prewiew');
            //$table->string('icon');
            $table->softDeletes();
            $table->timestamps();

            // Индексы
            $table->index(['module_id', 'status']);  // Для фильтрации уроков модуля
            $table->index('order');  // Для сортировки
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('lessons');
    }
};
