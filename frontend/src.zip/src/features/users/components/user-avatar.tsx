import type { User } from "@/features/auth/types"
import {
    Avatar,
    AvatarFallback,
    AvatarImage,
} from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import {
    getUserAvatarUrl,
    getUserInitials,
} from "@/features/users/lib/user-display"

type UserAvatarProps = {
    user: Pick<User, "name" | "email" | "avatar" | "avatar_url">
    className?: string
    size?: "default" | "sm" | "lg"
}

export function UserAvatar({
    user,
    className,
    size = "default",
}: UserAvatarProps) {
    const avatarUrl = getUserAvatarUrl(user)
    const initials = getUserInitials(user.name, user.email)

    return (
        <Avatar size={size} className={cn(className)}>
            {avatarUrl && (
                <AvatarImage
                    src={avatarUrl}
                    alt={user.name}
                    referrerPolicy="no-referrer"
                />
            )}

            <AvatarFallback>
                {initials}
            </AvatarFallback>
        </Avatar>
    )
}