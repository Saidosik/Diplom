import type { User } from "@/features/auth/types"
import { ProfileBreadcrumbs } from "@/features/profile/components/profile-breadcrumbs"
import { ProfileHero } from "@/features/profile/components/profile-hero"
import { ProfileTabs } from "@/features/profile/components/profile-tabs"
import { ProfileStatGrid } from "@/features/profile/components/profile-stat-grid"
import { ProfileAccountCard } from "@/features/profile/components/profile-account-card"
import { ProfileLearningCard } from "@/features/profile/components/profile-learning-card"
import { ProfileCommunityCard } from "@/features/profile/components/profile-community-card"

type ProfilePageContentProps = {
    user: User
}

export function ProfilePageContent({ user }: ProfilePageContentProps) {
    return (
        <div className="mx-auto w-full max-w-7xl space-y-6">
            <ProfileBreadcrumbs />

            <div className="space-y-1">
                <h1 className="text-2xl font-semibold tracking-tight">
                    Профиль
                </h1>

                <p className="text-sm text-muted-foreground">
                    Личный кабинет, активность сообщества и прогресс обучения.
                </p>
            </div>

            <ProfileHero user={user} />

            <ProfileTabs />

            <ProfileStatGrid />

            <div className="grid gap-6 xl:grid-cols-[340px_minmax(0,1fr)]">
                <aside className="space-y-4">
                    <ProfileAccountCard user={user} />
                </aside>

                <section className="min-w-0 space-y-4">
                    <ProfileLearningCard />
                    <ProfileCommunityCard />
                </section>
            </div>
        </div>
    )
}