import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function ProfileTabs() {
    return (
        <Tabs defaultValue="overview">
            <TabsList variant="line">
                <TabsTrigger value="overview">
                    Обзор
                </TabsTrigger>

                <TabsTrigger value="activity" disabled>
                    Активность
                </TabsTrigger>

                <TabsTrigger value="learning" disabled>
                    Обучение
                </TabsTrigger>

                <TabsTrigger value="settings" disabled>
                    Настройки
                </TabsTrigger>
            </TabsList>
        </Tabs>
    )
}