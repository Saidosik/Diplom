import {
    CalendarDays,
    CheckCircle2,
    MailWarning,
    Pencil,
} from "lucide-react"

import type { User } from "@/features/auth/types"
import { UserAvatar } from "@/features/users/components/user-avatar"
import {
    formatProfileDate,
    getUserRoleLabel,
} from "@/features/users/lib/user-display"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

type ProfileHeroProps = {
    user: User
}

export function ProfileHero({ user }: ProfileHeroProps) {
    const isEmailVerified = Boolean(
        user.is_email_verified || user.email_verified_at
    )

    return (
        <Card className="border bg-card shadow-sm">
            <CardContent className="p-0">
                <div className="h-28 border-b bg-gradient-to-r from-primary/25 via-primary/10 to-transparent" />

                <div className="px-6 pb-6">
                    <div className="-mt-10 flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
                        <div className="flex flex-col gap-4 sm:flex-row sm:items-end">
                            <UserAvatar
                                user={user}
                                size="lg"
                                className="size-24 border-4 border-card text-2xl shadow-sm"
                            />

                            <div className="space-y-3 pb-1">
                                <div>
                                    <h2 className="text-2xl font-semibold tracking-tight">
                                        {user.name}
                                    </h2>

                                    <p className="text-sm text-muted-foreground">
                                        {user.email}
                                    </p>
                                </div>

                                <div className="flex flex-wrap items-center gap-2">
                                    <Badge variant="secondary">
                                        {getUserRoleLabel(user.role)}
                                    </Badge>

                                    {isEmailVerified ? (
                                        <Badge className="bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/10 dark:text-emerald-400">
                                            <CheckCircle2 className="mr-1 size-3" />
                                            Почта подтверждена
                                        </Badge>
                                    ) : (
                                        <Badge variant="destructive">
                                            <MailWarning className="mr-1 size-3" />
                                            Почта не подтверждена
                                        </Badge>
                                    )}

                                    <Separator
                                        orientation="vertical"
                                        className="hidden h-4 sm:block"
                                    />

                                    <span className="inline-flex items-center gap-1.5 text-sm text-muted-foreground">
                                        <CalendarDays className="size-4" />
                                        Зарегистрирован {formatProfileDate(user.created_at)}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <Button variant="outline" disabled>
                            <Pencil className="size-4" />
                            Редактировать профиль
                        </Button>
                    </div>
                </div>
            </CardContent>
        </Card>
    )
}