import type { Metadata } from "next"
import { Geist, Geist_Mono, JetBrains_Mono } from "next/font/google"

import { OAuthToastHandler } from "@/components/auth/oauth-toast-handler"

import { cn } from "@/lib/utils"

import "./globals.css"
import { AppProviders } from "@/components/providers/app-providers"
import { Suspense } from "react"

const geistSans = Geist({
    subsets: ["latin"],
    variable: "--font-sans",
})

const geistHeading = Geist_Mono({
    subsets: ["latin"],
    variable: "--font-heading",
})

const jetbrainsMono = JetBrains_Mono({
    subsets: ["latin"],
    variable: "--font-mono",
})

export const metadata: Metadata = {
    title: "Информационное сообщество",
    description: "Платформа публикаций, вопросов и LMS",
}

export default function RootLayout({
    children,
}: Readonly<{
    children: React.ReactNode
}>) {
    return (
        <html
            suppressHydrationWarning
            lang="ru"
            className={cn(
                "h-full antialiased",
                geistSans.variable,
                geistHeading.variable,
                jetbrainsMono.variable,
                "font-sans"
            )}
        >
            <body className="min-h-full bg-background text-foreground">
                <AppProviders>

                    <Suspense fallback={null}>
                        <OAuthToastHandler />
                    </Suspense>
                    {children}
                </AppProviders>
            </body>
        </html>
    )
}